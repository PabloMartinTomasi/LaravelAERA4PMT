<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Listado de videojuegos</title>
</head>
<body>

    <h1>Listado de videojuegos</h1>

    <?php if(isset($success)): ?>
        <p style="color: green;">
            <?php echo e($success); ?>

        </p>
    <?php endif; ?>

    <hr>

    <?php $__currentLoopData = $videojuegos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $videojuego): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <h2>ID del videojuego <?php echo e($videojuego['id']); ?></h2>

        <p>Nombre: <?php echo e($videojuego['nombre']); ?></p>

        <p>Plataforma: <?php echo e($videojuego['plataforma']); ?> minutos</p>

        <p>Precio: <?php echo e($videojuego['precio']); ?> €</p>

        <a href="<?php echo e(route('videojuegos.show', $videojuego['id'])); ?>">
            Ver detalle videojuego
        </a>

        <hr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\LaravelAERA4PMT\resources\views/videojuegos/index.blade.php ENDPATH**/ ?>