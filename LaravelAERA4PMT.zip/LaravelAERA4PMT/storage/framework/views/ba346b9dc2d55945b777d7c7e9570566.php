<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title><?php echo e($videojuego['nombre']); ?></title>
</head>
<body>

    <h1><?php echo e($videojuego['nombre']); ?></h1>

    <p>
        <strong>ID:</strong>
        <?php echo e($videojuego['id']); ?>

    </p>

    <p>
        <strong>Nombre:</strong>
        <?php echo e($videojuego['nombre']); ?>

    </p>

    <p>
        <strong>Plataforma:</strong>
        <?php echo e($videojuego['plataforma']); ?>

    </p>

    <p>
        <strong>Precio:</strong>
        <?php echo e($videojuego['precio']); ?>

    </p>


    <a href="<?php echo e(route('videojuegos.index')); ?>">
        Volver a la cartelera
    </a>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\LaravelAERA4PMT\resources\views/videojuegos/show.blade.php ENDPATH**/ ?>